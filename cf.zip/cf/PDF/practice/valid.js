

document.addEventListener("DOMContentLoaded",function(){
    document.querySelector("form").addEventListener('submit',function(event){
       
        const file = document.getElementById('excel').value.trim();
        let isValid = true;

        if(file ===""){
            document.getElementById('excelerr').textContent = "Please Upload the Excel file.";
            isValid = false;
        } else{
            document.getElementById('excelerr').textContent = "";
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
});
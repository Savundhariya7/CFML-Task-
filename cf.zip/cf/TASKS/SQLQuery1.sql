create table Cartoon(
No int Primary key identity(1,1),
Name varchar(20),
Channel varchar(20),
Likes decimal(11,2))

select * from Cartoon
drop table Cartoon
sp_columns 'Cartoon'
sp_help 'Cartoon'

INSERT INTO Cartoon(Name,Channel,Likes) 
values('Barbie', 'POGO',500000),
('Jay Jagnnath','POGO',7000000);

INSERT INTO Cartoon(Name,Channel,Likes)
values('Shinchan','Hungama',1000000),
('Doraemon','Disneyp',4000000),
('Ben','Cartoon Network',5000000);


select top 1 * from 
(select Top 2 * from Cartoon order by Likes desc )AS TopTwo 
order by Likes asc;

 DELETE from Cartoon where Name = 'Barbie'

 update Cartoon
 set channel = 'Sonic Nick'
 where Name='Ninja Hattori';

 select * from cartoon

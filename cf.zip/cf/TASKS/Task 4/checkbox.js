function CheckAll()
 {
    let inputs = document.querySelectorAll('.Check');
    for (let i = 0; i < inputs.length; i++) 
        {
        inputs[i].checked = true;
        }
}

function UncheckAll()
{
    let inputs = document.querySelectorAll('.Check');
    for (let i = 0; i < inputs.length; i++) 
        {
        inputs[i].checked = false;
        }
}

function ToggleAll()
{
    let inputs = document.querySelectorAll('.Check');
    for (let i = 0; i < inputs.length; i++) 
        {
        inputs[i].checked = !inputs[i].checked  ;
        }
}


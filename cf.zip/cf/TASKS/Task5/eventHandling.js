
// document.addEventListener('click', function() {   // click func handle left click
//     alert("Left Button clicked");
// });

// document.addEventListener('contextmenu', function(event) {
//     event.preventDefault();                  //contextmenu handle the right click
//     alert("Right Button clicked");
// });



document.addEventListener('mousedown',function(event){
   if(event.button === 1)
   {
    alert("Middle Button of the mouse is Clicked")
   }
   else if(event.button === 2)
   {
    alert("Right Button  of the mouse is Clicked")
   }
   else
    {
        alert("Left Button  of the mouse is Clicked")
    }
   
});




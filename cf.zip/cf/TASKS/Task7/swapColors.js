$(document).ready(function() {
    let $lastClicked = null;

    // Function to swap colors
    function swapColors($elem1, $elem2) {
        let color1 = $elem1.css('background-color');
        let color2 = $elem2.css('background-color');
        $elem1.css('background-color', color2);
        $elem2.css('background-color', color1);
    }

    // Target all divs within #square1
    $('#square1 div').click(function() {
        const $current = $(this);  // accessing curr. ele
        if ($lastClicked && $lastClicked[0] !== $current[0]) {
            swapColors($lastClicked, $current);
            $lastClicked = null;
        } else {
            $lastClicked = $current; 
        }
    });
});

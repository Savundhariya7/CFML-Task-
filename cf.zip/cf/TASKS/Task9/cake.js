
$(document).ready(function() {

    const cakes = {
        'cake6': 20,
        'cake8': 35,
        'cake10': 45,
        'cake12': 60
    };

    const candlePrice = 5;
    const inscriptionPrice = 20;
    const flavours = {
        'Choco': 50,
        'orange': 70,
        'rainbow': 150,
        'vanilla': 50
    };

    function calculateTotal() {
        let totalPrice = 0;
// cake selection --> input[name ='cake']:checked -> input elemnet should have the same name for the radio 
        const cakePrice = $("input[name='cake']:checked").attr('id');
        if (cakePrice) {
            totalPrice += cakes[cakePrice];
        }

        // Flavour selection
        const selectedFlavor = $('#flavour').val();
        if (selectedFlavor !== 'select') {
            totalPrice += flavours[selectedFlavor];
        }

        // Candle price selection
        if ($('#candleCheckbox').is(":checked")) {
            totalPrice += candlePrice;
        }

        // Inscription selection
        if ($('#inscriptionCheckbox').is(":checked")) {
            totalPrice += inscriptionPrice;
            $('#words').show();
        }
        else{
            $('words').hide();
        }


        // Total amount display
        $('#totalAmount').text("Total Amount for Order: $" + totalPrice);
    }

    $("input[name='cake']").change(calculateTotal);
    $("#flavour").change(calculateTotal);
    $("#candleCheckbox").change(calculateTotal);
    $("#inscriptionCheckbox").change(calculateTotal);

    calculateTotal();
});


















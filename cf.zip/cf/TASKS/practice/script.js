


$('document').ready(function(){
    $('#click').click(function(){
        $('p').eq(2).css({'color':'blue', 'font-size':'33px'});
        
    })
})
  
      
   

 

 CREATE TABLE todo(
 Id int identity(1,1),
 list varchar(50))

 SELECT * FROM todo

 TRUNCATE table todo
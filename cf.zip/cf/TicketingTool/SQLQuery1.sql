

USE DATABASE tickettool


CREATE TABLE PMUsers (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(30) ,
    CODE VARCHAR(6) ,
    verified INT DEFAULT 0
);


CREATE TABLE PMuserinfo(
Id INT AUTO_INCREMENT PRIMARY KEY,
Email VARCHAR(30),
NAME VARCHAR(30),
PASSWORD VARCHAR(10),
WORK VARCHAR(70))

`internalemployeesinfo`
SELECT * FROM PMuserinfo

CREATE TABLE projectTeam (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Project_Name VARCHAR(100),
    NAME VARCHAR(50),
    Team VARCHAR(500),
    ROLE VARCHAR(50) DEFAULT 'Admin,Creator'
);


UPDATE PMuserinfo
SET project_id  = NULL;

CREATE TABLE ticket_info(
Ticket_id INT,
Project_Name VARCHAR(700),
Issue_type VARCHAR(30),
STATUS VARCHAR(20),
summary VARCHAR(800),
DESCRIPTION LONGTEXT,
Assignee VARCHAR(40),
Reporter VARCHAR(40),
priority VARCHAR(20),
Linked_issue VARCHAR(30),
Issue VARCHAR(600),
project_id INT,
Due_date VARCHAR(20),
image LONGTEXT,
FILE LONGTEXT,
start_date VARCHAR(20))


  CREATE TABLE Notes_info(
  notes_id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT,
  notes_content LONGTEXT,
  written_by VARCHAR(100),
  written_on VARCHAR(30)
  )


SELECT * FROM PMUsers

SELECT * FROM PMuserinfo

SELECT * FROM projectTeam

SELECT * FROM ticket_info


TRUNCATE TABLE PMuserinfo

UPDATE projectTeam
SET team = TRIM(',' FROM REPLACE(CONCAT(',',team,','), ',hazzle@gmail.com,', ','))
WHERE FIND_IN_SET('hazzle@gmail.com',team)
AND id = 13

UPDATE projectTeam
SET team = TRIM(',' FROM REPLACE(CONCAT(',', team, ','), ',hazzle@gmail.com,', ','))
WHERE FIND_IN_SET('hazzle@gmail.com', team)
AND id = 13;


    SELECT COUNT(*) AS recordCount  FROM PMuserinfo

            WHERE email =  'fg@gmail.com'

	SELECT COUNT(*) AS recordCount
            FROM PMUsers
            WHERE email = 'sky@gmail.com'

	    SELECT COUNT(*) AS recordCount  
         FROM PMuserinfo
            WHERE Email = 'sky@gmail.com'

	  SELECT COUNT(*) FROM PMuserinfo
            WHERE email =  'sky@gmail.com'
            AND PASSWORD = 'Sky@2002'
            
                   SELECT NAME FROM PMuserinfo
                   
SELECT COUNT(*) AS total_projects
FROM projectTeam
INNER JOIN PMuserinfo 
ON FIND_IN_SET(projectTeam.Id, PMuserinfo.project_id) 
WHERE PMuserinfo.email = 'star@gmail.com'
AND projectTeam.active_status = 1;
                   
                   
		SELECT    
		  projectTeam.Team, 
                  projectTeam.Project_Name, 
                  projectTeam.Name AS ProjectTeamName, 
                  PMuserinfo.project_id,
                  PMuserinfo.Name AS PMUserName,
                  projectTeam.Id,
                  PMuserinfo.work,
                  projectTeam.active_status,
                  projectTeam.Admin_name
                FROM 
                    projectTeam
                INNER JOIN 
                    PMuserinfo 
                ON 
                    FIND_IN_SET(projectTeam.Id, PMuserinfo.project_id) 
                WHERE 
                    PMuserinfo.email = 'sky@gmail.com'
                    AND projectTeam.active_status = 1
                    
                    
 SELECT COUNT(*) FROM projectTeam
 WHERE admin_name IN('star')
 
    SELECT notes_image FROM Notes_info
            WHERE project_id = 1
            AND ticket_id = 1
            ORDER BY notes_id DESC
            LIMIT 1
 



DELETE FROM Notes_info
WHERE notes_id = 3;


     
     
SELECT ticket_info.*,
      PMuserinfo.name
FROM ticket_info
INNER JOIN PMuserinfo ON ticket_info.assignee = pmuserinfo.email
WHERE ticket_info.project_id = 4
AND ticket_info.assignee = 'new02@gmail.com'
ORDER BY ticket_info.ticket_id ASC

 SELECT ticket_info.Ticket_id,
        ticket_info.reporter,
        PMuserinfo.name, 
        PMuserinfo.email
FROM ticket_info
INNER JOIN PMuserinfo ON ticket_info.reporter = pmuserinfo.email
WHERE ticket_info.project_id = 5


 SELECT 
   ticket_info.reporter,
   PMuserinfo.name, 
   PMuserinfo.email
   FROM ticket_info
   INNER JOIN PMuserinfo 
   ON ticket_info.reporter = PMuserinfo.email
   WHERE ticket_info.project_id = 5
   
SELECT NAME, email 
FROM PMuserinfo
WHERE email NOT IN ('sky@gmail.com') 
AND NAME NOT IN ('king');

  SELECT COUNT(*) AS Notification_count FROM notifications
            WHERE STATUS = 'unread'

USE DATABASE tickettool


CREATE TABLE PMUsers (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(30) ,
    CODE VARCHAR(6) ,
    verified INT DEFAULT 0
);


CREATE TABLE PMuserinfo(`training`
Id INT AUTO_INCREMENT PRIMARY KEY,
Email VARCHAR(30),
NAME VARCHAR(30),
PASSWORD VARCHAR(10),
WORK VARCHAR(70))

SELECT * FROM PMUsers
SELECT * FROM PMuserinfo


SELECT email,NAME  FROM PMuserinfo
WHERE email LIKE 's%'

CREATE TABLE projectTeam (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Project_Name VARCHAR(100),
    NAME VARCHAR(50),
    Team VARCHAR(500),
    ROLE VARCHAR(50) DEFAULT 'Admin,Creator'
);


ALTER TABLE projectTeam 
ADD COLUMN InvitationToken VARCHAR(255);

ALTER TABLE projectTeam 
ADD COLUMN Accepted INT DEFAULT 0;

ALTER TABLE projectTeam 
ADD COLUMN clicked INT DEFAULT 0;

ALTER TABLE  PMuserinfo
ADD COLUMN Project_id INT;

ALTER TABLE projectTeam
DROP COLUMN clicked; 

ALTER TABLE projectTeam
DROP COLUMN Accepted; 


SELECT * FROM projectTeam

DROP TABLE projectTeam

TRUNCATE projectTeam

SELECT COUNT(*) FROM projectTeam
                WHERE FIND_IN_SET('star@gmail.com',Team)
                AND invitationtoken='DDB2A644-99FB-3B9C-0AE61CAF0AE7F481'
                
UPDATE PMuserinfo
SET Project_id = 5
WHERE email ='moon@gmail.com' IN (SELECT team FROM projectTeam);



UPDATE PMuserinfo
SET Project_id = 1
FROM PMuserinfo
JOIN projectTeam ON PMuserinfo.email = projectTeam.team
WHERE projectTeam.team = 'star@gmail.com';

  UPDATE projectTeam
                SET clicked = 1 
                WHERE InvitationToken ='7794F82C-9AE7-5AC8-5A169716785256FF'
                
  UPDATE PMuserinfo
                SET Project_id = 2
                WHERE email ='star@gmail.com'
                
 ALTER TABLE PMuserinfo
 MODIFY COLUMN Project_id VARCHAR(400)





SELECT 
    projectTeam.Team, 
    projectTeam.Project_Name, 
    projectTeam.Name, 
    PMuserinfo.project_id,
    PMuserinfo.Name,
    PMuserinfo.work
FROM 
    projectTeam
INNER JOIN 
    PMuserinfo 
ON 
    PMuserinfo.project_id = projectTeam.Id
WHERE 
   projectTeam.Id = 6;
   
SELECT email,NAME  
            FROM PMuserinfo
            WHERE email LIKE 's%'
            AND FIND_IN_SET(1,Project_id)
 SELECT NAME FROM PMuserinfo
        WHERE FIND_IN_SET(6,project_id)

            
            
CREATE TABLE ticket_info(
Ticket_id INT,
Project_Name VARCHAR(700),
Issue_type VARCHAR(30),
STATUS VARCHAR(20),
summary VARCHAR(800),
DESCRIPTION LONGTEXT,
Assignee VARCHAR(40),
Reporter VARCHAR(40),
priority VARCHAR(20),
Linked_issue VARCHAR(30),
Issue VARCHAR(600),
project_id INT,
Due_date VARCHAR(20),
image LONGTEXT,
FILE LONGTEXT,
start_date VARCHAR(20))

 TRUNCATE TABLE ticket_info
 
      



 DROP TABLE ticket_info

ALTER TABLE ticket_info 
ADD COLUMN Due_date VARCHAR(20);

ALTER TABLE ticket_info 
ADD COLUMN start_date VARCHAR(20);

 SELECT email,NAME  
            FROM PMuserinfo
            WHERE (email LIKE 'm%'
            OR NAME LIKE 's%')
            AND WORK NOT IN('Human Resources','Project Management')
 
SELECT NAME 
FROM PMuserinfo
WHERE FIND_IN_SET(5, project_id)
AND NAME != 'moon'


SELECT MAX(ticket_id) FROM ticket_info


    UPDATE ticket_info 
    SET STATUS = 'pending' 
    WHERE Ticket_id = (
        SELECT max_id 
        FROM (SELECT MAX(Ticket_id) AS max_id FROM ticket_info) AS derived_table
    )

 ALTER TABLE ticket_info
 MODIFY COLUMN STATUS VARCHAR(70)

 ALTER TABLE ticket_info
 MODIFY COLUMN DESCRIPTION LONGTEXT
 
          SELECT NAME 
          FROM PMuserinfo
          WHERE FIND_IN_SET(2, project_id)
          AND NAME != 'king'
          
          
  CREATE TABLE Notes_info(
  notes_id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT,
  project_id VARCHAR(300),
  notes_content LONGTEXT,
  written_by VARCHAR(100),
  written_on VARCHAR(30)
  )
  
  DROP TABLE Notes_info
  
      SELECT *  FROM ticket_info
      WHERE project_id = 2
            AND  assignee = 'moon'
            
            SELECT * FROM ticket_info
            WHERE STATUS IN(pending,QA IN progress)

            SELECT * FROM ticket_info  
            WHERE assignee IN('eg')
     
            SELECT * FROM ticket_info  
            WHERE priority IN(low,high)

        
            SELECT * FROM ticket_info  
            WHERE reporter IN (king,eg)
            
       SELECT NAME 
          FROM PMuserinfo
          WHERE FIND_IN_SET(2, project_id)
          AND NOT WORK = 'human resources'



 SELECT * FROM ticket_info
 
 ALTER TABLE projectTeam
 ADD COLUMN Active_status VARCHAR(50) DEFAULT 1
      
 ALTER TABLE projectTeam
 ADD COLUMN Admin_name VARCHAR(70)
 
  ALTER TABLE projectTeam
 ADD COLUMN Creator_name VARCHAR(70)
 
 ALTER TABLE projectTeam DROP COLUMN Active_status;

  SELECT NAME FROM PMuserinfo
  WHERE email IN ('sky@gmail.com','star@gmail.com','moon@gmail.com','hazzle@gmail.com','eg@gmail.com')


SELECT NAME, email 
FROM PMuserinfo 
WHERE FIND_IN_SET(1, project_id) 
AND Email NOT IN ('sky@gmail.com');
                    
SELECT NAME, email FROM PMuserinfo 
WHERE (project_id IS NULL OR NOT FIND_IN_SET(1, project_id));

     UPDATE projectteam
            SET team = TRIM(BOTH ',' FROM REPLACE(CONCAT(',', team, ','), ',eg@email.com,', ','))
            WHERE FIND_IN_SET('eg@email.com', team);

  ALTER TABLE ticket_info
 ADD COLUMN first_response_time VARCHAR(70)
 
  ALTER TABLE Notes_info
 ADD COLUMN notes_image LONGTEXT
 
   ALTER TABLE ticket_info
 ADD COLUMN ticket_create_time LONGTEXT
 
   UPDATE ticket_info
  SET reporter  = 'sky@gmail.com'
     WHERE ticket_id = '3'
     AND project_id = '4'

 
UPDATE projectTeam
SET Active_status = 1
WHERE Id = 3


CREATE TABLE notifications (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    ticket_id INT,
    project_id INT,
    assigned_to VARCHAR(255),
    message TEXT,
    STATUS ENUM('unread', 'read') DEFAULT 'unread',
    created_at TIMESTAMP 
);


SELECT * FROM PMUsers

SELECT * FROM PMuserinfo

SELECT * FROM projectTeam

SELECT * FROM Notes_info 

SELECT * FROM notifications
           
  TRUNCATE Notes_info
  
  TRUNCATE projectTeam

  TRUNCATE ticket_info
  
  TRUNCATE Notes_info 
  
  TRUNCATE notifications
  
  
  UPDATE PMuserinfo
  SET project_id  = NULL;
          project_name

$(document).ready(function() {
    $("#forms").on("submit", function(event) {
        var input = $("#value").val();
        var regex = /^(\d+)(,\d+)*$/;
        var numberCount = input.split(",").length;
        
        $("#error").hide();
        $("#err-msg").hide();
        
        if (!regex.test(input)) {
            event.preventDefault(); 
            $("#error").show();
        }
        else if (numberCount < 2) {
            event.preventDefault(); 
            $("#err-msg").show();
        }
      
    });
});





document.addEventListener("DOMContentLoaded", function ()
{
    document.querySelector('form').addEventListener('submit',function(event){

        let isValid = true;
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
         
        if(username === ""){
            document.getElementById('user-err').textContent="Please Enter the username";
            isValid = false;
        }
        else{
            document.getElementById('user-err').textContent="";
        }

        if(password === ""){
            document.getElementById('pwd-err').textContent="Please Enter the password";
            isValid = false;
        }
        else{
            document.getElementById('pwd-err').textContent="";
        }

        if(!isValid){
            event.preventDefault();
        }
    })
})
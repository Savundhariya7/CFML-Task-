Framework One Sample Application - QBall
Raymond Camden 2010
http://www.raymondcamden.com/index.cfm/2010/2/27/Framework-One-Sample-Application--QBall
Updated and included in FW/1 (with permission) by Jeremey Hustman 2014

** Using ColdFusion ORM is not recommended, but it does work. **

This is an example application that uses Framework One (FW/1) and ColdFusion ORM (tested on both Adobe and Railo).

You must first create a datasource 'qBall' in ColdFusion administrator pointing to an empty MySql database.

If using a database other than MySql, adjust your dialect settings in Application.cfc 'this.ormsettings' to reflect your environment.

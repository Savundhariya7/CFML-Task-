


CREATE TABLE Production(
Month varchar(20),
Production int,
Sales int,
Expenses int,
Profit int)

INSERT INTO Production
VALUES
('January', 20000, 15000, 5000, 10000),
('February', 15000, 14070, 930, 13140),
('March', 25000, 23700, 1300, 22400),
('April', 30000, 26000, 4000, 22000),
('May', 28000, 21000, 7000, 14000),
('June',31000,29580,5000, 24580),
('July', 35500, 32000, 7000, 25000),
('August', 38000, 36000, 8000, 28000);

SELECT * FROM Production

TRUNCATE TABLE Production


CREATE TABLE Energy(
Time_of_Day varchar(10),
Motivation_Level int,
Energy_Level int
)

SELECT * FROM Energy

INSERT INTO Energy
VALUES
('8.00 AM',1,0),
('9.00 AM',2,1),
('10.00 AM',3,2),
('11.00 AM',5,3),
('12.00 PM',6,4),
('1.00 PM',7,5),
('2.00 PM',8,6),
('3.00 PM',9,7),
('4.00 PM',10,8),
('5.00 PM',10,9)
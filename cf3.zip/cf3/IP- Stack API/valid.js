

document.addEventListener('DOMContentLoaded',function(){
    document.querySelector('form').addEventListener('submit',function(event){
        const ipaddress = document.getElementById('ipadd').value.trim();
        const ipPattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        let isvalid = true;
        if(ipaddress === ""){
            document.getElementById('iperr').textContent="IP Address is Required";
            isvalid =false;
        }else if(!ipPattern.test(ipaddress)){
            document.getElementById('iperr').textContent = "InValid IP address.";
            isvalid = false;
        } else{
            document.getElementById('iperr').textContent = "";
        }

        if(!isvalid){
            event.preventDefault();
        }
    })
})
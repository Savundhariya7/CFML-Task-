



document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('form').addEventListener('submit', function(event) {
        const imgname = document.getElementById('Imgname').value.trim();
        const imgdesc = document.getElementById('Imgdescribe').value.trim();
        const imgfile = document.getElementById('Imgfile').files[0];
        const validFiles = ['image/png', 'image/jpeg', 'image/gif'];
    
        const namePattern = /^[A-Za-z]+$/;
        let isValid = true;
    
        if (imgname === "") {
            document.getElementById('name-err').textContent = "Image name is required.";
            isValid = false;
        } else if (!namePattern.test(imgname)) {
            document.getElementById('name-err').textContent = "Please enter an image name that contains only alphabets.";
            isValid = false;
        } else {
            document.getElementById('name-err').textContent = "";
        }
    
        if (imgdesc === "") {
            document.getElementById('desc-err').textContent = "Image description is required.";
            isValid = false;
        } else {
            document.getElementById('desc-err').textContent = "";
        }
    
        if (!imgfile) {
            document.getElementById('file-err').textContent = "Please upload the image.";
            isValid = false;
        } else {
            if (!validFiles.includes(imgfile.type)) {
                document.getElementById('file-err').textContent = "Please upload the file in one of the following formats: PNG, JPG, or GIF.";
                isValid = false;
            } else if (imgfile.size > 1048576) { 
                document.getElementById('file-err').textContent = "Please upload a file less than 1MB.";
                isValid = false;
            } else {
                document.getElementById('file-err').textContent = "";
            }
        }
    
        if (!isValid) {
            event.preventDefault();
        }
    });
});


SELECT * FROM Authors

SELECT au_fname,au_lname FROM Authors 
WHERE state = 'UT'

SELECT au_lname FROM Authors
WHERE au_lname like '%a%'

SELECT * FROM Authors
WHERE phone = '707 448-4982'
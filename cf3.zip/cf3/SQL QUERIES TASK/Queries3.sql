

SELECT * FROM Publishers

SELECT count(*) AS Total_Number_Of_Publishers FROM Publishers

SELECT * FROM Employee
WHERE fname ='Howard'

SELECT * FROM Employee
WHERE job_id = 12

SELECT * FROM Jobs
WHERE job_id = 12

SELECT CONCAT(Employee.fname,'  ',Employee.minit,'  ',Employee.lname)AS Name,jobs.job_desc AS Job_Description From Employee
INNER JOIN Jobs
ON Employee.job_id = Jobs.job_id
WHERE job_desc ='Editor'

SELECT CONCAT(Employee.fname,'  ',Employee.minit,'  ',Employee.lname) AS Name,Jobs.job_desc AS Job_Describtion From Employee
LEFT JOIN Jobs
ON  Employee.job_id = Jobs.job_id
WHERE job_desc <> 'Managing Editor'

SELECT *  FROM Jobs
WHERE job_desc='Business Operations Manager'

SELECT * FROM Employee
WHERE job_id = 3
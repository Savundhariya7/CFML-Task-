

SELECT CONCAT(address,'  ',city,'  ',state,' - ',zip) Address FROM Authors
WHERE au_lname = 'Panteley' AND au_fname='Sylvia' 


SELECT * FROM Employee

SELECT CONCAT(fname,'  ',minit,'  ',lname) AS Name , hire_date FROM Employee


SELECT * FROM Titles

SELECT title AS Book_Title FROM Titles
WHERE type='Psychology'
 

 SELECT * FROM Titles

 SELECT type,COUNT(title) AS Total_Number_Of_Books FROM Titles
 WHERE type='business'
 GROUP BY type

 SELECT title,pubdate FROM Titles
 Where title = 'Life Without Fear'

 SELECT * FROM Publishers

SELECT Titles.title FROM Titles 
LEFT JOIN Publishers
ON Titles.pub_id = Publishers.pub_id
WHERE pub_name ='Binnet & Hardley'


SELECT title from titles
WHERE pub_id = 0877

SELECT * from Titles
WHERE title='Straight Talk About Computers'

SELECT * FROM Titleauthor 
WHERE title_id = 'BU7832'

SELECT * from Authors
Where au_id='274-80-9391'

SELECT Authors.au_fname, Authors.au_lname FROM Authors
INNER JOIN Titleauthor 
ON Authors.au_id =  Titleauthor.au_id
INNER JOIN Titles
ON Titles.title_id = Titleauthor.title_id
WHERE title = 'Straight Talk About Computers'





SELECT pub_id, AVG(price)AS Average_Price  FROM Titles
WHERE pub_id = 1389
GROUP BY pub_id

SELECT COUNT(*) AS Total_NumberOf_Rows FROM Titles

SELECT * FROM Titles

SELECT * FROM Stores

SELECT stor_address FROM Stores
WHERE state In('WA','CA')


-- BETWEEN includes the given data also eg it includes both 1989-01-01 and 1992-12-31
SELECT * FROM Employee
WHERE hire_date BETWEEN '1989-01-01' AND '1992-12-31'
ORDER BY hire_date ASC

SELECT * FROM Employee

SELECT fname,lname FROM Employee
WHERE job_id = 6
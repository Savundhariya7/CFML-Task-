

SELECT * FROM Stores

SELECT DISTINCT state , COUNT(stor_name) Number_Of_Stores from Stores
GROUP BY state

SELECT title,price FROM Titles
WHERE price > 10.00
ORDER BY price ASC



        SELECT CONCAT(fname,' ',minit,' ',lname) AS NAME,hire_date FROM Employee
        WHERE hire_date BETWEEN '1991-01-01' AND '1992-12-31'


  
        SELECT CONCAT(fname,' ',lname) AS Name FROM Employee
        WHERE minit =''



        SELECT CONCAT(fname,' ',minit,' ',lname) AS Name , hire_date AS StartDate FROM Employee
        ORDER BY hire_date ASC



         SELECT CONCAT(Employee.fname,' ',Employee.minit,' ',Employee.lname) AS NAMES FROM Employee
         INNER JOIN Jobs
         ON Employee.job_id = jobs.job_id
         WHERE job_desc ='Sales Representative'
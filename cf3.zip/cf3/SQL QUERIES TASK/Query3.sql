
-- INNER JOIN: Returns only the rows with matching values in both tables.
-- LEFT JOIN: Returns all rows from the left table, and the matched rows from the right table. If no match, NULL values are returned for columns from the right table.
-- RIGHT JOIN: Returns all rows from the right table, and the matched rows from the left table. If no match, NULL values are returned for columns from the left table.

1. Display/find the total number of Publishers in publishers table. 

        SELECT count(*) AS Total_Number_Of_Publishers FROM Publishers


2. Display the employee name and job description of all employees with the same job as Howard. 

        SELECT CONCAT(Employee.fname,'  ',Employee.minit,'  ',Employee.lname)AS Name,jobs.job_desc AS Job_Description From Employee
        INNER JOIN Jobs
        ON Employee.job_id = Jobs.job_id
        WHERE job_desc ='Editor'


3. Display the employee name and job description of all employees whose are not Managing Editor. 

        SELECT CONCAT(Employee.fname,'  ',Employee.minit,'  ',Employee.lname) AS Name,Jobs.job_desc AS Job_Describtion From Employee
        LEFT JOIN Jobs
        ON  Employee.job_id = Jobs.job_id
        WHERE job_desc <> 'Managing Editor'
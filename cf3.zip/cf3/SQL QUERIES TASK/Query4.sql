

1. Display the maximum and minimum price of the book. 

        SELECT MAX(price) AS Maximum_Price_Of_The_Book FROM Titles 

        SELECT MIN(price) AS Minimum_Price_Of_The_Book FROM Titles


2. Display the total book price for each type. 

        SELECT DISTINCT type AS Book_Type, SUM(price) AS Total_Price From Titles
        WHERE type IS NOT NULL
        GROUP BY type


3. Find out the Publisher for the following books 

   ‘Cooking with Computers: Surreptitious Balance Sheet’, 
   ‘Silicon Valley Gastronomic Treats’, 
   ‘Is Anger the Enemy?’, 
   ‘Fifty Years in Buckingham Palace Kitchens’.

    SELECT Titles.title,Publishers.* FROM Titles 
    INNER JOIN Publishers
    ON Titles.pub_id = Publishers.pub_id
    WHERE title IN('Cooking with Computers:Surreptitious Balance Sheet', 
   'Silicon Valley Gastronomic Treats', 
   'Is Anger the Enemy?', 
   'Fifty Years in Buckingham Palace Kitchens')
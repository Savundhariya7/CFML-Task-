

 1. Display/find the given authors complete address information. [Panteley Sylvia]

        SELECT CONCAT(address,'  ',city,'  ',state,' - ',zip) Address FROM Authors
        WHERE au_lname = 'Panteley' AND au_fname='Sylvia' 


2. Display only the hire date and employee name for each employee.

        SELECT CONCAT(fname,'  ',minit,'  ',lname) AS Name , hire_date FROM Employee


3. Display all the books which come under ‘Psychology’ type.

        SELECT title AS Book_Title FROM Titles
        WHERE type='Psychology'


1. Find the total number of books in ‘Business’ type.

        SELECT type,COUNT(title) AS Total_Number_Of_Books FROM Titles
        WHERE type='business'
        GROUP BY type


2. Display the published date for this book ‘Life Without Fear’. 

        SELECT title,pubdate FROM Titles
        Where title = 'Life Without Fear'


3. Display all the books title published by ‘Binnet & Hardley’. 

        SELECT Titles.title FROM Titles 
        LEFT JOIN Publishers
        ON Titles.pub_id = Publishers.pub_id
        WHERE pub_name ='Binnet & Hardley'


4. Find the authors first name and last name for this book ‘Straight Talk About Computers’.

        SELECT Authors.au_fname, Authors.au_lname FROM Authors
        INNER JOIN Titleauthor 
        ON Authors.au_id =  Titleauthor.au_id
        INNER JOIN Titles
        ON Titles.title_id = Titleauthor.title_id
        WHERE title = 'Straight Talk About Computers'
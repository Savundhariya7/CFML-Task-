

1. Select the average price in the table titles for  pub _id is 1389.

        SELECT pub_id, AVG(price)AS Average_Price  FROM Titles
        WHERE pub_id = 1389
        GROUP BY pub_id


2. What are the total numbers of rows in the titles table

        SELECT COUNT(*) AS Total_NumberOf_Rows FROM Titles


3. List the address of all stores  in the state WA or CA in the table stores

        SELECT stor_address FROM Stores
        WHERE state In('WA','CA')


4. List the date between  the year 1989 to 1992 in the table employee

        SELECT * FROM Employee
        WHERE hire_date BETWEEN '1989-01-01' AND '1992-12-31'
        ORDER BY hire_date ASC


5. List the first name and last name of the employee in the employee table where the job_id  is 6

        SELECT fname,lname FROM Employee
        WHERE job_id = 6


1. How many stores are in each unique state in the stores table? Select the state and display the number of store  in each. Hint: count is used to count rows in a column,
   sum works on numeric data only.

            SELECT DISTINCT state , COUNT(stor_name) Number_Of_Stores from Stores
            GROUP BY state


2. Select the title and price in the table title that the price is greater than 10.00. Display the results in Ascending order based on the price

            SELECT title,price FROM Titles
            WHERE price > 10.00
            ORDER BY price ASC
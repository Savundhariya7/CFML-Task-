
CREATE DATABASE databasename

 --  DISPLAY THE DATABASES PRESENT IN SYSTEM  
 SELECT * FROM exercise.sys.databases


 -- DROP the database if it exists(general syntax)
 DROP DATABASE [IF EXIST] database_name    

 USE database name

 SELECT name
FROM sys.schemas;

CREATE SCHEMA Arts;
CREATE TABLE Arts.Students (
    StudentID INT PRIMARY KEY,
    Name NVARCHAR(100),
    Major NVARCHAR(100));

-- Schema is nothing but the each and every column in tables


    

    var intervalTime = setInterval(() => {
       var result =  showTime();
        // console.log(result);
        
        document.getElementById('time').innerHTML = result. hours_and_minute;
        document.getElementById('date').innerHTML = result.dates;
    }, 500);





    function showTime(){
        let object = new Date();

        var hour = object.getHours();
        var minutes =  object.getMinutes();
        // var secs =  object.getSeconds();
    
        // var am_pm = hour > 12 ? 'PM' : 'AM';
        // hour =  hour % 12;
        // hour = hour ? hour : 12;
        // minutes = minutes < 10 ? "0" + minutes : minutes;



        var hours_and_minute = object.toLocaleTimeString({
                hour12: true,
             
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit"
        });

        var dates = object.toLocaleDateString({
                year: "2-digit",
                month: "2-digit",
                day: "2-digit"
        })

        
    
        return {
            hours_and_minute,
            dates
        };
    }


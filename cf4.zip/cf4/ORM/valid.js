

document.addEventListener("DOMContentLoaded",function(){
    document.querySelector('form').addEventListener('submit',function(event){
        isValid = true;
        const empname = document.getElementById('empname').value.trim();
        const empage = document.getElementById('empage').value.trim();
        const namePattern = /^[A-Za-z]+$/;
        if(empname === ""){
            document.getElementById('name-err').textContent ="Employee Name is required.";
            isValid = false;
        }
        else if(!namePattern.test(empname))
        {
            document.getElementById('name-err').textContent = "Please enter the Employee name contains only alphabets.";
            isValid = false;
        }
        else{
            document.getElementById('name-err').textContent = "";
        }

        if(empage === ""){
            document.getElementById('age-err').textContent = "Employee age is required.";
        }
        else if (isNaN(empage) || empage < 0) {
            document.getElementById('age-err').textContent = "Employee age must be a positive number.";
            isValid = false;
        } else if (empage < 20) {
            document.getElementById('age-err').textContent = "Employee age must be at least 20.";
            isValid = false;
        } else if (empage > 60) {
            document.getElementById('age-err').textContent = "Employee age cannot be greater than 60.";
            isValid = false;
        } else {
            document.getElementById('age-err').textContent = "";
        }

        if(!isValid){
            event.preventDefault();
        }

    })
})
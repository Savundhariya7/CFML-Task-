
$(document).ready(function () {
     
  
$('form').on('submit',function(event){
    var inputValue =  $('#value').val();
    var  err = parseFloat(inputValue);
   if(isNaN(err) || err < 0)
   {
    $('#error').show();
    event.preventDefault();
   }
   else{
    $('#error').hide();
   }
});
  
});
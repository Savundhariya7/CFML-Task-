
$(document).ready(function () {
    var err = $(this).val()
    if( !err || !isNaN(err))
    {
        $("#error").show();
    }
    else{
        $("#error").hide();
    }
});



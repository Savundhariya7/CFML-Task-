
CREATE TABLE Jobs(
job_id int PRIMARY KEY identity(1,1),
cname varchar(50),
weblink varchar(50),
jtitle varchar(50),
jtype varchar(50),
jlocation varchar(50),
jcountry varchar(30),
jemail varchar(20),
jdesc varchar(300),
jactive varchar(10) DEFAULT 'inactive',
user_id int FOREIGN KEY REFERENCES jobsiteUser(user_id))



DROP Table Jobs

DELETE FROM Jobs 
WHERE jtype='full time';



Select* from Jobs

SELECT  COUNT(jtitle) FROM Jobs
 SELECT  COUNT(DISTINCT cname) AS Companycount FROM Jobs
 SELECT  COUNT(*) FROM Jobs
  SELECT COUNT(*) AS positionTot FROM Jobs

  SELECT * FROM Jobs 
    WHERE jcountry='china'
  ORDER BY job_id
  OFFSET 0 ROWS
  FETCH NEXT 8 ROWS ONLY


   SELECT * FROM Jobs 
  ORDER BY Jtitle
  LIMIT 2;

  DELETE FROM Jobs 
  WHERE job_id = 1007
  SELECT  DISTINCT jcountry FROM Jobs
            ORDER BY jcountry ASC


Select* from Jobs where 
(cname like 'd%')
--OR (jtitle like' %a%') or (jtype like '%a%')


CREATE TABLE jobsiteUser(
user_id int identity(1,1) PRIMARY KEY,
uname varchar(50),
urole varchar(10),
uemail varchar(50),
ucname varchar(50))

Select * from jobsiteUser 

TRUNCATE TABLE jobsiteUser 
DROP TABLE jobsiteUser

ALTER TABLE jobsiteUser
ADD upwd VARCHAR(20);

UPDATE jobsiteUser
SET upwd = 'sky'
WHERE user_id = 1;

UPDATE jobsiteUser
SET upwd = 'star'
WHERE user_id = 2;

UPDATE jobsiteUser
SET upwd = 'hazzle'
WHERE user_id = 3;

CREATE TABLE jobsiteApply(
apply_id int identity(1,1) PRIMARY KEY,
fname varchar(40),
mname varchar(40),
lname varchar(40),
dob varchar(11),
email varchar(20),
stadd varchar(50),
city varchar(50),
state varchar(50),
zip varchar(20),
gender varchar(10),
exper varchar(10),
contact varchar(15),
joinn varchar(20),
cv varchar(200),
job_id int FOREIGN KEY(job_id) REFERENCES Jobs(job_id),
user_id int FOREIGN KEY REFERENCES jobsiteUser(user_id),
hr_id int) 

SELECT user_id FROM Jobs WHERE job_id = 6;

DROP table jobsiteApply



Select * from Image

SELECT COUNT(*) AS usernameCount
            FROM jobsiteUser
            WHERE uname = 'sky'

 SELECT urole FROM  jobsiteUser
WHERE uname = 'sky'
            AND uemail ='sky@gmail.com'

SELECT 
    Jobs.jtitle,
    Jobs.jlocation,
    Jobs.jcountry,
	Jobs.weblink,
    concat(jobsiteApply.fname, ' ',
    jobsiteApply.mname, '  ',
    jobsiteApply.lname) AS name,
    jobsiteApply.email,
    jobsiteApply.contact,
	jobsiteApply.exper,
	concat(jobsiteApply.city,
	jobsiteApply.state) as Location,
	jobsiteApply.cv

FROM jobsiteApply 
JOIN Jobs  ON jobsiteApply.job_id = Jobs.job_id
WHERE 
    jobsiteApply.hr_id = 1 AND Jobs.jtitle ='Books Artist';

	
	SELECT
    Jobs.jtitle,
	Jobs.cname,
    Jobs.jlocation,
    Jobs.jcountry,
    Jobs.jtype,
    Jobs.weblink

FROM jobsiteApply 
JOIN Jobs  ON jobsiteApply.job_id = Jobs.job_id
WHERE 
    jobsiteApply.user_id = 2; 



	SELECT jtitle from Jobs where user_id = 3

	UPDATE Jobs 
	SET user_id = 1
	WHERE job_id= 2 

	SELECT 

    CONCAT(jobsiteApply.fname, ' ', 
           jobsiteApply.mname, ' ', 
           jobsiteApply.lname) AS name,
    jobsiteApply.email,
    jobsiteApply.contact,
    jobsiteApply.exper,
    CONCAT(jobsiteApply.city, ' at ', jobsiteApply.state) AS Location,
    jobsiteApply.cv
FROM jobsiteApply 
JOIN Jobs ON jobsiteApply.job_id = Jobs.job_id
WHERE 
    (jobsiteApply.hr_id = 1) 
    AND (Jobs.jtitle = 'Books  Artist');

	 SELECT COUNT(*) AS applied FROM jobsiteApply
	 WHERE job_id = 6 AND user_id =2
	

	   SELECT user_id, COUNT(*) AS userCount
            FROM jobsiteUser
            WHERE uname = 'sky'
            AND uemail = 'sky@gmail.com'
            AND upwd =  'sky'
            GROUP BY user_id

			SELECT job_id,jtype,jtitle,cname,jlocation,jcountry,jactive FROM Jobs
			  WHERE user_id = 1
            ORDER BY jtype
            OFFSET 1 ROWS
            FETCH NEXT 2 ROWS ONLY
          
		   SELECT  COUNT(jtitle) AS Jobcount FROM Jobs
       
                WHERE user_id =  1
                AND jcountry = 'India'

	 SELECT COUNT(jtitle)  FROM Jobs
            WHERE jcountry = 'India'

  SELECT * FROM Jobs  WHERE jactive='active'

       SELECT 
                COUNT(jtitle) AS Positioncnt,
                COUNT(DISTINCT cname) AS Companycnt,
                COUNT(DISTINCT jlocation) AS locationNos,
                COUNT(DISTINCT jcountry) AS countryCt 
            FROM Jobs 
            WHERE jactive = 'active' 
			AND user_id = 1 
			AND (jcountry='china'
			OR jtype='remote')

			
       SELECT 
                COUNT(jtitle) AS Positioncnt,
                COUNT(DISTINCT cname) AS Companycnt,
                COUNT(DISTINCT jlocation) AS locationNos,
                COUNT(DISTINCT jcountry) AS countryCt 
            FROM Jobs 
            WHERE jactive = 'active' 
	        AND user_id = 1
			AND jcountry='china'
			AND  
            
			
	Select * from jobsiteApply
    SELECT * FROM Jobs 
	Select * from jobsiteUser  


	SELECT 
                COUNT(jtitle) AS Positioncnt,
                COUNT(DISTINCT cname) AS Companycnt,
                COUNT(DISTINCT jlocation) AS locationNos,
                COUNT(DISTINCT jcountry) AS countryCt 
            FROM Jobs 
            WHERE jactive = 'active'

           
                AND user_id = <cfqueryparam value="#arguments.user_id#" cfsqltype="cf_sql_integer">
                <cfif arguments.valueCountry NEQ ''>
                    AND (jcountry = <cfqueryparam value="#arguments.valueCountry#" cfsqltype="cf_sql_varchar">
                </cfif>
        
                <cfif arguments.valueType NEQ ''>
                    AND jtype = <cfqueryparam value="#arguments.valueType#" cfsqltype="cf_sql_varchar"> )
                </cfif>
            </cfif>
            <cfif userroleCheck(session.uname, session.uemail) EQ "applicant">
            <cfif arguments.valueCountry NEQ ''>  
                AND (jcountry = <cfqueryparam value="#arguments.valueCountry#" cfsqltype="cf_sql_varchar">
            </cfif>
        
            <cfif arguments.valueType NEQ ''>
                OR jtype = <cfqueryparam value="#arguments.valueType#" cfsqltype="cf_sql_varchar">)
            </cfif>
        </cfif>


		    <cffunction name="userroleCheck" access="public" returntype="any">
        <cfargument name="user_id" type="numeric" required = "true">
        <cfargument name="uemail" type="string" required="true">
  

        <cfquery  name="checkRole" datasource="training">
            SELECT urole FROM  jobsiteUser
            WHERE user_id = '1'
          
        </cfquery>
        <cfreturn checkRole.urole>
    </cffunction>
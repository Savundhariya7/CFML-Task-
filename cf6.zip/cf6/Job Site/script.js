



$(document).ready(function () {
 
    let currentpage = <cfoutput>#page#</cfoutput>;
    const totalPages = <cfoutput>#totalPages#</cfoutput>;  
    // let country = $('.country').val();
    // console.log("Country:",country)
    console.log(currentpage);
    // The window object is the global object in a browser's JavaScript environment. It represents the current browser window or tab, and all global variables and functions in a script are properties of this object.
    // By attaching a function or variable to window, you make it accessible from anywhere in the JavaScript code running in that window.
        window.changePage = function(direction) {
        if (direction === 'next') {
            currentpage++;
        } else if (direction === 'pre' && currentpage > 1) {
            currentpage--;
        }
    
        // Ensure we don't go beyond the available pages
        if (currentpage > totalPages) {
            currentpage = totalPages;
        } else if (currentpage < 1) {
            currentpage = 1;
        }

        $('#searchbtn').on('click', function () {
          fetchJobs();
        });

         function fetchJobs(){
            let countrySearch = $('#countrysearch').val();
            let typeSearch = $('#jobsearch').val();
            let keyword = $('#search').val();
            let userid = $('#user_id').val();
            $.ajax({
                url:'compo.cfc',
                type:'GET',
                dataType: 'JSON',
                data:{
                    method:'countryfind',
                    countrysearch :countrySearch,
                    jobsearch:typeSearch,
                    page: currentpage,
                    search:keyword,
                    limit: 8,
                    user_id :userid
                  
                },
                success:function(response) {
                   console.log("search:",response);
                   console.log(" fetch respose len:",response.length)

                    let tbody = $('#joblistcontainer tbody');
                    tbody.empty();
                    
                    if(response.length > 0){
                    for (let i = 0; i < response.length; i++) {
                        console.log("resposelen:",response.length)
                        const jo = response[i];
                          
                    if(jo.jactive === "inactive"){
                        // alert(2)
                        //  console.log("test")
                        //  alert("inactive")
                            let row = '<tr style="color: red;" id="row' + jo.job_id + '" >' +
                                //   '<td>'+jo.job_id +'</td>'+
                                  '<td > <button class="btn btn-danger" >' + jo.jtype + '</button></td>' +
                                  '<td class=" strikethrough">' + jo.jtitle + '</td>' +
                                  '<td class=" strikethrough">' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td class=" strikethrough">' + jo.jcountry + '</td>' +
                                  '<td >'+ '<button class="btn btn-danger detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }else{
                    let row = '<tr id="row' + jo.job_id + '">' +
                                //   '<td>'+jo.job_id +'</td>'+
                                '<td> <button class="btn btn-info">' + jo.jtype + '</button></td>' +
                                  '<td>' + jo.jtitle + '</td>' +
                                  '<td>' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td>' + jo.jcountry + '</td>' +
                                  '<td>'+ '<button class="btn  detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }
            }} else{
                tbody.append('<p>NO JOBS FOUND </p>');
            }
                },
                error:function(xhr,error,status){
                    alert("Error : " + error);
                }
            })
        };

        
        

    // userrole - hr
    let userrole = $('#hrrole').val();
    console.log("Userrole : ",userrole)
    let userid = $('#user_id').val();
    if(userrole === 'hr'){
    $.ajax({
            url: 'compo.cfc',
            type: 'GET',
            dataType: 'JSON',
            data: {
                method: 'hrjob',
                page: currentpage,
                limit: 8,
                user_id :userid
            },
            success: function(response) {
                // alert("Entered Success")
                let data = response;
                console.log(response);
                let tbody = $('#joblistcontainer tbody');
                tbody.empty();
                console.log("Length :",data.length)
                // alert(3)
                for (let i = 0; i < data.length; i++) {
                    // alert(4)
                    const jo = data[i];   
                    if(jo.jactive === "inactive"){
                        // alert(2)
                        //  console.log("test")
                        //  alert("inactive")
                            let row = '<tr style="color: red;" id="row' + jo.job_id + '" >' +
                                //   '<td>'+jo.job_id +'</td>'+
                                  '<td > <button class="btn btn-danger" >' + jo.jtype + '</button></td>' +
                                  '<td class=" strikethrough">' + jo.jtitle + '</td>' +
                                  '<td class=" strikethrough">' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td class=" strikethrough">' + jo.jcountry + '</td>' +
                                  '<td >'+ '<button class="btn btn-danger detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }else{
                    let row = 'test<tr id="row' + jo.job_id + '">' +
                                //   '<td>'+jo.job_id +'</td>'+
                                  '<td> <button class="btn btn-info">' + jo.jtype + '</button></td>' +
                                  '<td>' + jo.jtitle + '</td>' +
                                  '<td>' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td>' + jo.jcountry + '</td>' +
                                  '<td>'+ '<button class="btn detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }
                }
            },
            error: function(xhr, status, error) {
                console.error("Error: ", error);
            }
        });
    } else{
        $.ajax({
            url: 'compo.cfc',
            type: 'GET',
            dataType: 'JSON',
            data: {
                method: 'latestJob',
                page: currentpage,
                limit: 8

            },
            success: function(response) {
                // alert("Entered Success")
                let data = response;
                console.log(response);
                let tbody = $('#joblistcontainer tbody');
                tbody.empty();
                console.log("Length :",data.length)
                // alert(3)
                for (let i = 0; i < data.length; i++) {
                    // alert(4)
                    const jo = data[i];
                    // console.log("cedrfgbjg",jo);
                    console.log(jo.job_id,"--",jo.jtitle,"--",jo.cname,"--",jo.jcountry,"--",jo.jtype,"--",jo.jactive,"--")

                    
                    if(jo.jactive === "inactive"){
                        // alert(2)
                        //  console.log("test")
                        //  alert("inactive")
                            let row = '<tr style="color: red;" id="row' + jo.job_id + '" >' +
                                //   '<td>'+jo.job_id +'</td>'+
                                  '<td > <button class="btn btn-danger" >' + jo.jtype + '</button></td>' +
                                  '<td class=" strikethrough">' + jo.jtitle + '</td>' +
                                  '<td class=" strikethrough">' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td class=" strikethrough">' + jo.jcountry + '</td>' +
                                  '<td >'+ '<button class="btn btn-danger detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }else{
                    let row = 'test<tr id="row' + jo.job_id + '">' +
                                //   '<td>'+jo.job_id +'</td>'+
                                  '<td> <button class="btn btn-info">' + jo.jtype + '</button></td>' +
                                  '<td>' + jo.jtitle + '</td>' +
                                  '<td>' + jo.cname +'  ' +'at'+ '  ' + jo.jlocation + '</td>' + 
                                  '<td>' + jo.jcountry + '</td>' +
                                  '<td>'+ '<button class="btn detail" name="detail"  data-id="' + jo.job_id + '">DETAILS</button>' +'</td>'
                                  '</tr>';
                    tbody.append(row);
                }
                }
            },
            error: function(xhr, status, error) {
                console.error("Error: ", error);
            }
        });
    }
    };




    //previous and next function
    $('#pre').on('click', function() {
        changePage('pre');
    });
    $('#next').on('click', function() {
        changePage('next');
    });

    // Initial job load
    changePage(currentpage);

    $('#postjob').on('click',function(){
        let user_id = $(this).data('id');
        window.location.href = "post.cfm";
    })

    $('#joblistcontainer').on('click','.detail',function(e){
        e.preventDefault();
        let jobid = $(this).data('id');
        console.log(jobid)
        window.location.href = "details.cfm?job_id="+jobid;
    });

    $(".valueCountry").click(function(e){
        e.preventDefault();
    let valuecountry = $(this).data('value');
    alert(valuecountry)
    
    $.ajax({
        url: 'compo.cfc',
        type: 'GET',
        dataType: 'JSON',
        data: {
            method: 'countryfilter',
            valueCountry: valuecountry,
            page: currentpage,
            limit: 8
        },
        success: function(response) {
            alert(2);
            console.log("second", response);
            let tbody = $('#joblistcontainer tbody');
            tbody.empty();
            console.log("country Length:", response.length);
        
            if (response.length > 0) {
                for (let i = 0; i < response.length; i++) {
                    const cjo = response[i];
                    console.log("country active" , cjo.jactive)
                    let row;
                    if (cjo.jactive === "inactive") {
                        row = '<tr style="color: red;" id="row' + cjo.job_id + '">' +
                            '<td><button class="btn btn-danger">' + cjo.jtype + '</button></td>' +
                            '<td class="strikethrough">' + cjo.jtitle + '</td>' +
                            '<td class="strikethrough">' + cjo.cname + ' at ' + cjo.jlocation + '</td>' +
                            '<td class="strikethrough">' + cjo.jcountry + '</td>' +
                            '<td><button class="btn btn-danger detail" name="detail" data-id="' + cjo.job_id + '">DETAILS</button></td>' +
                            '</tr>';
                    } else {
                        row = '<tr id="row' + cjo.job_id + '">' +
                            '<td><button class="btn btn-info">' + cjo.jtype + '</button></td>' +
                            '<td>' + cjo.jtitle + '</td>' +
                            '<td>' + cjo.cname + ' at ' + cjo.jlocation + '</td>' +
                            '<td>' + cjo.jcountry + '</td>' +
                            '<td><button class="btn detail" name="detail" data-id="' + cjo.job_id + '">DETAILS</button></td>' +
                            '</tr>';
                    }
                    tbody.append(row);
                }
            } else {
                tbody.append('<p>NO JOBS FOUND</p>');
            }
        },
        error: function(xhr, error, status) {
            console.error("Error", error);
        }
    });


 
   

$('.valueTypes').on('click', function(e) {
        e.preventDefault();
        let valuetype = $(this).data('value');
        alert(valuetype);
                    
        $.ajax({
            url: 'compo.cfc',
            type: 'GET',
            dataType: 'JSON',
            data: {
                method: 'typeFilter',
                valueType: valuetype, 
                page: 1, 
                limit: 8             
            },
            success: function(response) {
                alert(1);
                let data = response;
                let tbody = $('#joblistcontainer tbody');
                tbody.empty();
                console.log("Length:", data.length);
            
                if (data.length > 0) {   
                    for (let i = 0; i < data.length; i++) {
                        const tjo = data[i];
                        let row;
                      console.log("types active" , tjo.jactive)
                        if (tjo.jactive === "inactive") {
                            row = '<tr style="color: red;" id="row' + tjo.job_id + '">' +
                                '<td><button class="btn btn-danger">' + tjo.jtype + '</button></td>' +
                                '<td class="strikethrough">' + tjo.jtitle + '</td>' +
                                '<td class="strikethrough">' + tjo.cname + ' at ' + tjo.jlocation + '</td>' + 
                                '<td class="strikethrough">' + tjo.jcountry + '</td>' +
                                '<td><button class="btn btn-danger detail" name="detail" data-id="' + tjo.job_id + '">DETAILS</button></td>' +
                                '</tr>';
                        } else {
                            row = '<tr id="row' + tjo.job_id + '">' +
                                '<td><button class="btn btn-info">' + tjo.jtype + '</button></td>' +
                                '<td>' + tjo.jtitle + '</td>' +
                                '<td>' + tjo.cname + ' at ' + tjo.jlocation + '</td>' + 
                                '<td>' + tjo.jcountry + '</td>' +
                                '<td><button class="btn detail" name="detail" data-id="' + tjo.job_id + '">DETAILS</button></td>' +
                                '</tr>';
                        }
                    
                        tbody.append(row);
                    }
                } else {
                    tbody.append('<p>NO JOBS FOUND</p>');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    });


    $('#appliedjobs').on('click',function(){
        window.location.href='appliedjob.cfm';
    })

    $("#appliedcandidate").on('click',function(){
        window.location.href ='appliedcandidate.cfm';
    })

    $('#logout').on('click',function(){
        window.location.href="login.cfm";
    })

    });
});
      




document.addEventListener("DOMContentLoaded",function(){
    document.querySelector("form").addEventListener('submit',function(event){

        const name = document.getElementById('name').value.trim();
        const email =  document.getElementById('email').value.trim();
        const wishfile = document.getElementById('wish').value.trim();
        const messg = document.getElementById('mesg').value.trim();

        const mailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const namePattern = /^[A-Za-z]+$/;

        let isvalid = true;

        if(name ===""){
            document.getElementById('nameerr').textContent ="Birthday Baby's name Required. ";
            isvalid=false;
        } else if(!namePattern.test(name)){
            document.getElementById('nameerr').textContent = "Name should contains only alphabets.";
            isvalid = false;
        } else{
            document.getElementById('nameerr').textContent ="";
        }


        if(email === ""){
            document.getElementById('emailerr').textContent = "Email address is Required.";
            isvalid = false;
        } else if(!mailPattern.test(email)){
            document.getElementById('emailerr').textContent = "Please enter the correct email address.";
            isvalid= false;
        } else{
            document.getElementById('emailerr').textContent ="";
        }


        if(wishfile ===""){
            document.getElementById('fileerr').textContent = "Greeting Image is Required.";
            isvalid = false;
        } else{
            document.getElementById('fileerr').textContent = "";
        }


        if(messg === ""){
            document.getElementById('mesgerr').textContent = "Your Wishes are Required.";
            isvalid = false;
        } else {
            document.getElementById('mesgerr').textContent = "";
        }

        if(!isvalid){
            event.preventDefault();
        }
    })
})
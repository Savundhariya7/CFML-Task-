

CREATE TABLE Auctions (
    auction_id INT PRIMARY KEY identity(1,1),
    item_name VARCHAR(100),
    highest_bid DECIMAL(10, 2),
    start_date DATETIME,
    end_date DATETIME
);

CREATE TABLE auctionuser(
user_id INT PRIMARY KEY identity(1,1),
user_name varchar(20))

INSERT INTO auctionuser
VALUES('')

--to list the tables in db

SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE';


SELECT * from Auctions

 
CREATE TABLE image_table (
    id INT identity(1,1),
    image_name VARCHAR(255)
);

SELECT * FROM image_table
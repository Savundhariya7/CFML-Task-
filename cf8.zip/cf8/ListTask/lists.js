
$(document).ready(function () {

    $("#listform").on('submit',function(event){
        var inputValue = $("#listNumber").val();
        var regex = /^(\d+)(,\d+)*$/;
        if(!regex.test(inputValue))
        {
             $("#error").show();
             event.preventDefault();
        }

        else{
            $("#error").hide();
        }
    })
    
});
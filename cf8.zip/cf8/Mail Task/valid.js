

document.addEventListener('DOMContentLoaded', function(){
    document.querySelector('form').addEventListener('submit',function(event){
        
        const username = document.getElementById('username').value.trim();
        const email = document.getElementById('email').value.trim();
        const captcha = document.getElementById('captcha').value.trim(); 
        const generatedCaptcha = document.getElementById('generatedCaptcha').value.trim();
        const mailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const namePattern = /^[A-Za-z]+$/;
        const presentCaptcha = "srkljae";
        let isvalid = true;

        if(username ===""){
            document.getElementById('nameerr').textContent = "Username is required.";
            isvalid = false;
        } else if(!namePattern.test(username)){
            document.getElementById('nameerr').textContent = "Please enter the name only contains alphabets.";
            isvalid =  false;
        } else{
            document.getElementById('nameerr').textContent = "";
        }

        if(email === ""){
            document.getElementById('emailerr').textContent="Email is required.";
            isvalid = false;
        } else if(!mailPattern.test(email)){
            document.getElementById('emailerr').textContent = "Please enter the correct email address";
            isvalid = false;
        } else{
            document.getElementById('emailerr').textContent ="";
        }
        
        if(captcha ===""){
            document.getElementById('caperr').textContent = "Captcha is required";
            isvalid = false; 
        } else if(captcha != generatedCaptcha){
            document.getElementById('caperr').textContent ="Invalid Captcha! Please try again.";
            isvalid = false;
        }  
        else{
            document.getElementById('caperr').textContent = "";
        }

        if(!isvalid){
            event.preventDefault();
        }
    });
});



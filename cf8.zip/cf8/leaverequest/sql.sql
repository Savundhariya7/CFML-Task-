

DROP DATABASE newWorks;


CREATE DATABASE newworks;
USE  newworks

CREATE TABLE LeaveRequest (
Id INT  PRIMARY KEY AUTO_INCREMENT,
EmpId  VARCHAR(5), 
Email VARCHAR(70),
DATE VARCHAR(200),
LeaveReason LONGTEXT,
Approved INT DEFAULT 0,
Rejected INT DEFAULT 0,
RejectedReason VARCHAR(500)
)


ALTER TABLE LeaveRequest
ADD COLUMN contact VARCHAR(10)

ALTER TABLE LeaveRequest
ADD COLUMN STATUS VARCHAR(15)

ALTER TABLE LeaveRequest
ADD COLUMN Days VARCHAR(30)

ALTER TABLE LeaveRequest
ADD COLUMN travel VARCHAR(4)

ALTER TABLE LeaveRequest
ADD COLUMN emergencyAvailable VARCHAR(4)

ALTER TABLE LeaveRequest
MODIFY COLUMN Days DECIMAL(3,1)

ALTER TABLE LeaveRequest 
DROP COLUMN notification;

ALTER TABLE LeaveRequest 
CHANGE COLUMN requster requester VARCHAR(70);


DROP TABLE employeesInfo

CREATE TABLE internalemployeesInfo(
Emp_id INTEGER,
NAME VARCHAR(100),
Department VARCHAR(50),
ROLE VARCHAR(50),
Email VARCHAR(50),
PASSWORD VARCHAR(8))

SELECT * FROM internalemployeesInfo

TRUNCATE TABLE internalemployeesInfo


SELECT * FROM LeaveRequest

TRUNCATE TABLE LeaveRequest


 SELECT name.internalemployeesInfo,
	requester.LeaveRequest,
	date.LeaveRequest,
	leaveReason.LeaveRequest,
	contact.LeaveRequest,
	status.LeaveRequest,
	leavetype.LeaveRequest
	FROM internalemployeesInfo
	INNER JOIN LeaveRequest
ON internalemployeesInfo.emp_id = LeaveRequest.empId;
            WHERE email =  'sky@gmail.com'
            AND  emp_id = '100'
            
   SELECT 
    internalemployeesInfo.name,
    LeaveRequest.requester,
    LeaveRequest.date,
    LeaveRequest.leaveReason,
    LeaveRequest.contact,
    LeaveRequest.status,
    LeaveRequest.leavetype
FROM internalemployeesInfo 
INNER JOIN LeaveRequest  ON internalemployeesInfo.emp_id = LeaveRequest.empId
WHERE internalemployeesInfo.email = 'sky@gmail.com'
AND internalemployeesInfo.emp_id = '100';

SELECT * FROM LeaveRequest
WHERE requester = 'lisa@gmail.com'
AND empId = 201
ORDER BY Id DESC

 SELECT STATUS,empId,Leavetype FROM LeaveRequest
  WHERE empId = 100
  UPDATE LeaveRequest
  SET days = 2
  WHERE days IS NULL
  
  SELECT SUM(days) AS Sick_Leave_Count FROM LeaveRequest
  WHERE empId = 331
  AND STATUS IN('approved') 
  AND Leavetype IN('planned')
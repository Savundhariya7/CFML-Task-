document.addEventListener('DOMContentLoaded', function() {
  
    const emailInput = document.getElementById("email"); // Convert email uppercase to lowercase
    emailInput.addEventListener("input", function() {
        this.value = this.value.toLowerCase();
    });

    document.getElementById('createAccount').addEventListener('submit', function(event) {
        event.preventDefault();           // Prevent form from submitting by default

   
        const fname = document.getElementById('fname').value.trim();
        const lname = document.getElementById('lname').value.trim();
        const email = document.getElementById('email').value.trim(); 
        const password = document.getElementById('pwd').value.trim();
        const cpassword = document.getElementById('cpwd').value.trim();
        const gender = document.querySelector('input[name="gender"]:checked');
        const hobbies = document.querySelectorAll('input[name="hobby"]:checked');
        const income = document.getElementById('browser').value.trim();
        const range = document.getElementById('income').value;
        const profile = document.getElementById('profile').files.length > 0;
        const age = document.getElementById('age').value.trim();
        const bio = document.getElementById('bio').value.trim();

        let isValid = true; 

        const namePattern = /^[A-Za-z]+$/;
        if (fname === "")  {
            document.getElementById('fname-err').textContent = "First Name is required.";
            isValid = false;
        } else if(!namePattern.test(fname)) {
            document.getElementById('fname-err').textContent = "Please enter a first name that contains only alphabets.";
            isValid = false;
        } else {
            document.getElementById('fname-err').textContent = "";
        }

        if (lname === "") {
            document.getElementById('lname-err').textContent = "Last Name is required.";
            isValid = false;
        } else if(!namePattern.test(lname)) {
            document.getElementById('lname-err').textContent = "Please enter a last name that contains only alphabets.";
            isValid = false;
        } else {
            document.getElementById('lname-err').textContent = "";
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email === "" || !emailPattern.test(email)) {
            document.getElementById('email-err').textContent = "A valid email is required.";
            isValid = false;
        } else {
            document.getElementById('email-err').textContent = "";
        }

        if (password === "") {
            document.getElementById('pwd-err').textContent = "Password is required.";
            isValid = false;
        } else {
            document.getElementById('pwd-err').textContent = "";
        }

        if (cpassword === "" || cpassword !== password) {
            document.getElementById('cpwd-err').textContent = "Passwords must match.";
            isValid = false;
        } else {
            document.getElementById('cpwd-err').textContent = "";
        }

        if (!gender) {
            document.getElementById('gender-err').textContent = "Please select your gender.";
            isValid = false;
        } else {
            document.getElementById('gender-err').textContent = "";
        }

        if (hobbies.length < 2) {
            document.getElementById('hobby-err').textContent = "Please choose at least 2 hobbies.";
            isValid = false;
        } else {
            document.getElementById('hobby-err').textContent = "";
        }

        if (income === "") {
            document.getElementById('srcIncome-err').textContent = "Source of Income is required.";
            isValid = false;
        } else {
            document.getElementById('srcIncome-err').textContent = "";
        }

        if (!profile) {
            document.getElementById('img-err').textContent = "Please upload the profile picture.";
            isValid = false;
        } else {
            document.getElementById('img-err').textContent = "";
        }

        if (age === "" || isNaN(age) || age < 20 || age > 50) {
            document.getElementById('age-err').textContent = "Age must be between 20 and 50.";
            isValid = false;
        } else {
            document.getElementById('age-err').textContent = "";
        }

        if (bio === "") {
            document.getElementById('bio-err').textContent = "Bio is required.";
            isValid = false;
        } else {
            document.getElementById('bio-err').textContent = "";
        }

        if (isValid) {
            alert('Form submitted successfully!');
            // Submit the form programmatically if needed
            // document.getElementById('createAccount').submit();
        }
    });
});

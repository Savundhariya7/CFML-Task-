
document.addEventListener('DOMContentLoaded', function()    // standard event that fires when the initial HTML document has been completely loaded and parsed, without waiting for stylesheets, images, and subframes to finish loading.
{
    const arrayInput = document.getElementById('array');
    const positionInput = document.getElementById('position');
    const valueInput = document.getElementById('value');
    const replaceButton = document.getElementById('replaceButton');
    const resetButton = document.getElementById('resetButton');
    const originalArray = document.getElementById('originalArray');   
    const modifiedArray = document.getElementById('modifiedArray');
    const originalArrayLabel = document.getElementById('color'); 
    const modifiedArrayLabel = document.querySelector('.color'); 

    
   
    function replaceValues(){
       // currnt arr val
        let arrayValues = arrayInput.value.split(',').map(item => item.trim());  //map() =>> create new array by applying a provided function to each element of the original array
        const position = parseInt(positionInput.value.trim(),10);  // 10 is used accept number as decimal
        const newValue = valueInput.value.trim();

     originalArray.textContent =  arrayValues.join(', '); // display original arr
     originalArray.style.display = 'block'; // Show the original array
     originalArrayLabel.style.display = 'block'; 

     if(!isNaN(position) && position >= 0 && position<arrayValues.length ){
        arrayValues[position] = newValue;
     }
     else{
        alert("Invalid position");
     }
     modifiedArray.textContent = arrayValues;  // display modified arr
        modifiedArray.style.display = 'block'; 
       modifiedArrayLabel.style.display = 'block';
    }

    function resetForm()
    {
        arrayInput.value="";
        positionInput.value = "";
        valueInput.value ="";
        originalArray.textContent = '';
        modifiedArray.textContent = '';
        originalArray.style.display = 'none';
        modifiedArray.style.display = 'none';
        originalArrayLabel.style.display = 'none';
        modifiedArrayLabel.style.display = 'none';
    }

    replaceButton.addEventListener('click',replaceValues);
    resetButton.addEventListener('click',resetForm);

});




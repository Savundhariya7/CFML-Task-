$(document).ready(function() {
    var width = 10;

    $('#max').click(function() {
        if (width < 100) { 
            width += 10;
            $('#progress').css('width', width + '%');
            $('#progress').text(width + '%');
        }
    });

    $('#min').click(function() {
     

        if (width <= 100) { 
            width -= 10;
            $('#progress').css('width', width + '%');
            $('#progress').text(width + '%');
        }
        
    });

});
